<!DOCTYPE html>
<html>
<body>
<h1>JavaScript Functions</h1>
<script>
alert("helo");
alert(myFunction(1,2));
function myFunction(p1, p2) {
  return p1 * p2;
}
</script>

</body>
</html>
