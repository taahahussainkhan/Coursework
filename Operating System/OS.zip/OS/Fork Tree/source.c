#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(int argc,char const* argv[]){
	int a,b,c,d,e,f,g,h,i;
	b = fork();
	if (b == 0){
		d = fork();
		if(d == 0){
		printf("D: %d\n",d);
		h = fork();
		if(h == 0){
			i = fork();
			if (i == 0){
			printf("I: %d\n",i);
			}
			else {
			printf("H: %d\n",h);
			}
		}
		else {
		printf("D: %d\n",d);
		}
	}
		else{
		e = fork();
		if (e == 0){
		printf("E: %d\n",e);
		}
		else{
		f = fork();
		if (f == 0 ){
		printf("F: %d\n",f);
		}
		else {
		printf("B: %d\n",b);
		}
		}
		}
	}
	else{
	  c = fork();
	  if (c == 0){
	  	g = fork();
	  	if(g == 0){
	  	printf("G: %d\n",g);
	  	}
	  	else
	  	{
	  	printf("C: %d\n",c);
	  	}
	  }
	  else{
	  printf("A: %d\n",a);
	  }
	}

}
