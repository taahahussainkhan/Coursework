#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<errno.h>
#include<unistd.h>
#include<time.h>
int main(int argc,char const* argv[])
{
	int arr[5];
	srand(time(NULL));
	for(int i = 0;i<5;i++){
	arr[i] = rand() % 100;
	}
	int fd = open("sum",O_WRONLY | O_CREAT,0644);
	if (fd == -1){
	return 1;
	}
	for(int i =0 ;i<5;i++){
	if(write(fd,&arr[i],sizeof(int)) == -1){
	return 2;
	}
	printf("Wrote %d\n",arr[i]);
	}	
	close(fd);
	int fdr = open("sum",O_RDONLY);
	if(fdr == -1){
	return 3;
	}
	int s;
	if(read(fdr,&s,sizeof(int)) == -1){
	return 4;
	}
	printf("\nSum from prog2 is here: %d\n",s);
	
	return 0;
}
