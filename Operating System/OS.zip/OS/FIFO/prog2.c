#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<fcntl.h>
#include<errno.h>
int main(int argc,char const* argv[]){
	
	int arr[5];
	int fd = open("sum",O_RDONLY);
	if(fd == -1){return 1;}
	for(int i =0;i<5;i++){
	if(read(fd,&arr[i],sizeof(arr)) == -1){
	return 2;
	}
	}
	for(int i =0;i<5;i++){
	printf(" %d",arr[i]);
	}
	int sum = 0;
	for(int i =0;i<5;i++){
	sum += arr[i];
	}
	int fdw = open("sum",O_WRONLY);
	if(write(fdw,&sum,sizeof(int)) == -1){
	return 3;
	}
		

}
