#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/wait.h>
int main(int argc,char const* argv[]){
	char* arr[] = {
	"ping",
	"google.com",
	NULL
	};
	execvp("ping",arr);
}
