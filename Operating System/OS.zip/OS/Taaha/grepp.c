#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {
    int pipefd[2];

    // Create a pipe
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // Create a child process for grep
    if (fork() == 0) {
        // Redirect stdin to read from the input.txt file
        int inputFile = open("input.txt", O_RDONLY);
        dup2(inputFile, STDIN_FILENO);
        close(inputFile);

        // Redirect stdout to the write end of the pipe
        dup2(pipefd[1], STDOUT_FILENO);
        close(pipefd[0]);
        close(pipefd[1]);

        // Execute grep "m"
        execlp("grep", "grep", "m", NULL);
        perror("execlp grep");
        exit(EXIT_FAILURE);
    }

    // Create another child process for sort
    if (fork() == 0) {
        // Redirect stdin to read from the read end of the pipe
        dup2(pipefd[0], STDIN_FILENO);
        close(pipefd[0]);
        close(pipefd[1]);

        // Redirect stdout to the output.txt file
        int outputFile = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0666);
        dup2(outputFile, STDOUT_FILENO);
        close(outputFile);

        // Execute sort
        execlp("sort", "sort", NULL);
        perror("execlp sort");
        exit(EXIT_FAILURE);
    }

    // Close the pipe in the parent process
    close(pipefd[0]);
    close(pipefd[1]);

    // Wait for the child processes to complete
    for (int i = 0; i < 2; i++) {
        wait(NULL);
    }

    return 0;
}
