#include<iostream>
using namespace std;
int calcSum(int[], int);
int calcSum1(int[], int);
int main()
{
	int a[9], b[7], n = 0, n1 = 0;
	cout << "Enter  array 1 : ";
	for (int i = 0; i < 9; i++)
	{
		cin >> a[i];
	}
	n = calcSum(a, 9);
	cout << "Enter  array 2 : ";
	for (int i = 0; i < 7; i++)
	{
		cin >> b[i];
	}
	n1 = calcSum1(b, 7);
	cout << "Result is : " << n << endl;
	cout << "Result is : " << n1 << endl;
}

int calcSum(int a[], int size)
{
	int sum = 0;
	for (int i = 0; i < size; i++)
	{
		sum =sum + a[i];
	}
	return sum;
}
int calcSum1(int b[], int size)
{
	int sum = 0;
	for (int i = 0; i < size; i++)
	{
		sum = sum + b[i];
	}
	return sum;
}