#include<iostream>
using namespace std;
int calcMul(int);
int calcMul1(int);
int calcSum(int, int);
int main()
{
	int a = 0, b = 0, n = 0, m1 = 0, m2 = 0;
	cout << "Enter  number 1 : ";
	cin >> a;
	cout << "Enter  number 2 : ";
	cin >> b;
	m1 = calcMul(a);
	m2 = calcMul1(b);
	n = calcSum(m1, m2);
	cout << "Result is : " << n << endl;
}
int calcMul(int a)
{
	return a;
}
int calcMul1(int b)
{
	return b;
}
int calcSum(int a, int b)
{
	int sum = 0;
	sum = 3*a*b;
	return sum;
}