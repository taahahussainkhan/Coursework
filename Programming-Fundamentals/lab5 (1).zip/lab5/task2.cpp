#include<iostream>
using namespace std;
int calculator(int,int,char);
void addition(int,int);
void subtraction(int,int);
void mult(int,int);
void division(int,int);
int main()
{
	int n1 = 0,n2=0;
	char ch;
	cout << "Enter  number 1 : ";
	cin >> n1;
	cout << "Enter  number 2 : ";
	cin >> n2;
	cout << "Enter Character : ";
	cin >> ch;
	calculator(n1,n2,ch);
}
int calculator(int n1, int n2, char c)
{
	if (c == '+')
	{
		addition(n1, n2);
		return 1;
	}
	else if (c == '-')
	{
		subtraction(n1, n2);
		return 1;
	}
	else if (c == '*')
	{
		mult(n1, n2);
		return 1;
	}
	else if (c == '/')
	{
		division(n1, n2);
		return 1;
	}
	else
	{
		cout << "Wrong character !" << endl;
		return 0;
	}
	
}
void addition(int n1, int n2)
{
	cout << n1 << " + " << n2 << " = " << n1+n2 << endl;
}
void subtraction(int n1, int n2)
{
	cout << n1 << " - " << n2 << " = " << n1 - n2 << endl;
}
void mult(int n1, int n2)
{
	cout << n1 << " * " << n2 << " = " << n1 * n2 << endl;
}
void division(int n1, int n2)
{
	cout << n1 << " / " << n2 << " = " << n1 / n2 << endl;
}