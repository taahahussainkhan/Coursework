#include<iostream>
using namespace std;
int check(char [] ,int,int);
int check1(char[], int, int);
int main()
{
	char arr[20];
	int n = 0, m1 = 0, m2 = 0,len=0;
	cout << "Enter  name : ";
	cin.getline(arr,20);
	len = strlen(arr);
	m1 = check(arr, 20,len);
	check1(arr, 20, len);
	cout << endl;
	cout << "Result is : " << m1 << endl;
}
int check(char arr[] , int size, int len)
{
	int vowels = 0;
	for (int i = 0; i <= len; i++)
	{
		if (arr[i] == 'a' || arr[i] == 'e' || arr[i] == 'i' || arr[i] == 'o' || arr[i] == 'u')
		{
			vowels++;
		}
	}
	return vowels;
}
int check1(char arr[], int size, int len)
{
	cout << "Vowel found at index : ";
	for (int i = 0; i <= len; i++)
	{
		if (arr[i] == 'a' || arr[i] == 'e' || arr[i] == 'i' || arr[i] == 'o' || arr[i] == 'u')
		{
			cout << i << " ";
		}
	}
	return 1;
}