#include<iostream>
using namespace std;
void table(int);
int main()
{
	int n = 0;
	cout << "Enter a number to print its table : ";
	cin >> n;
	table(n);
}
void table(int m)
{
	for (int i = 1; i <= 6; i++)
	{
		cout << m << "*" << i << "=" <<m*i <<endl;
	}
}